namespace sa47.team8ad.SSIS.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public class MeasurementUnitViewModel
    {
        public MeasurementUnitViewModel()
        {
            Items = new HashSet<ItemViewModel>();
            SupplierItems = new HashSet<SupplierItemViewModel>();
        }

        [Key]
        public int UnitId { get; set; }

        [Required]
        [StringLength(30)]
        public string UnitName { get; set; }

        public int UnitQuantity { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ItemViewModel> Items { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SupplierItemViewModel> SupplierItems { get; set; }
    }
}

namespace sa47.team8ad.SSIS.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ItemAdjustmentViewModel
    {
        public int ItemAdjustmentId { get; set; }

        public int ItemId { get; set; }

        public int AdjustmentQuantity { get; set; }

        [StringLength(300)]
        public string Reason { get; set; }

        [Column(TypeName = "date")]
        public DateTime ItemAdjustmentDate { get; set; }

        public string EmployeeId { get; set; }

        [StringLength(20)]
        public string Status { get; set; }

        [StringLength(300)]
        public string Remark { get; set; }

        [ForeignKey("EmployeeId")]
        public virtual EmployeeViewModel Employee { get; set; }

        public virtual ItemViewModel Item { get; set; }
    }
}

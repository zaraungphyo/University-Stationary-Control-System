using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace sa47.team8ad.SSIS.Models
{
    public class ItemViewModel
    {
        public ItemViewModel()
        {
            Disbursements = new HashSet<DisbursementViewModel>();
            ItemAdjustments = new HashSet<ItemAdjustmentViewModel>();
            ItemRequisitionDetails = new HashSet<ItemRequisitionDetailViewModel>();
            SupplierItems = new HashSet<SupplierItemViewModel>();
        }

        public int ItemId { get; set; }
        public int CategoryId { get; set; }
        public string ItemDescription { get; set; }
        public int ReorderLevel { get; set; }
        public int ReorderQuantity { get; set; }
        public int QuantityOnHand { get; set; }
        public int UnitId { get; set; }

        public int? LocationId { get; set; }
        public string Status { get; set; }
        public string Remark { get; set; }

        public virtual CategoryViewModel Category { get; set; }


        public virtual ICollection<DisbursementViewModel> Disbursements { get; set; }

        //  public virtual ItemLocationViewModel ItemLocation { get; set; }

        public virtual MeasurementUnitViewModel MeasurementUnit { get; set; }
        public virtual ICollection<ItemAdjustmentViewModel> ItemAdjustments { get; set; }
        public virtual ICollection<ItemRequisitionDetailViewModel> ItemRequisitionDetails { get; set; }
        public virtual ICollection<SupplierItemViewModel> SupplierItems { get; set; }
    }
}
